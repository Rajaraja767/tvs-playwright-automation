# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: schedule.spec.ts >> TC05 - Chat shows bot reply and message input works
- Location: tests\schedule.spec.ts:33:5

# Error details

```
Error: browserType.launch: Executable doesn't exist at C:\Users\god\AppData\Local\ms-playwright\webkit-2370\Playwright.exe
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```