# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: schedule.spec.ts >> TC04 - Clicking a ticket opens its chat
- Location: tests\schedule.spec.ts:27:5

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Invalid url: "/app/tms/folders/schedule"
Call log:
  - navigating to "/app/tms/folders/schedule", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.beforeEach(async ({ page }) => {
> 4  |   await page.goto('/app/tms/folders/schedule');
     |              ^ Error: page.goto: Protocol error (Page.navigate): Invalid url: "/app/tms/folders/schedule"
  5  |   await expect(page).not.toHaveURL(/login/); // login aagalana inga fail aagum
  6  | });
  7  | 
  8  | test('TC01 - Schedule page loads with all main controls', async ({ page }) => {
  9  |   await expect(page.getByText('Schedule').first()).toBeVisible();
  10 |   await expect(page.getByText('Mine')).toBeVisible();
  11 |   await expect(page.getByText('Team')).toBeVisible();
  12 |   await expect(page.getByText('General Query')).toBeVisible();
  13 | });
  14 | 
  15 | test('TC02 - Ticket list is displayed with status badges', async ({ page }) => {
  16 |   await expect(page.getByText(/Tickets-\d{2}-\d{2}-\d{4}/).first()).toBeVisible();
  17 |   await expect(page.getByText(/Active|Open|Closed/).first()).toBeVisible();
  18 | });
  19 | 
  20 | test('TC03 - Mine and Team tabs can be switched', async ({ page }) => {
  21 |   await page.getByText('Team').click();
  22 |   await expect(page).toHaveURL(/schedule/);
  23 |   await page.getByText('Mine').click();
  24 |   await expect(page).toHaveURL(/schedule/);
  25 | });
  26 | 
  27 | test('TC04 - Clicking a ticket opens its chat', async ({ page }) => {
  28 |   await page.getByText(/Tickets-\d{2}-\d{2}-\d{4}/).first().click();
  29 |   await expect(page.getByPlaceholder('Type your message...')).toBeVisible();
  30 |   await expect(page.getByText('No Chat Selected')).toBeHidden();
  31 | });
  32 | 
  33 | test('TC05 - Chat shows bot reply and message input works', async ({ page }) => {
  34 |   await page.getByText(/Tickets-\d{2}-\d{2}-\d{4}/).first().click();
  35 |   const input = page.getByPlaceholder('Type your message...');
  36 |   await expect(input).toBeVisible();
  37 |   await input.fill('hello test');
  38 |   await input.press('Enter');
  39 |   await expect(page.getByText('hello test')).toBeVisible();
  40 | });
  41 | 
  42 | test('TC06 - Closed ticket opens and shows history', async ({ page }) => {
  43 |   await page.getByText('Closed').first().click();
  44 |   await expect(page.getByText('No Chat Selected')).toBeHidden();
  45 | });
  46 | 
  47 | test('TC07 - Back arrow returns to folder list', async ({ page }) => {
  48 |   await page.locator('[class*="back"], button:has(svg)').first().click(); // codegen-la correct locator edunga
  49 |   await expect(page).not.toHaveURL(/schedule$/);
  50 | });
```